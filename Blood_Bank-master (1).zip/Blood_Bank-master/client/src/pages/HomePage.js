import React from 'react'

const HomePage = () => {
  return (
    <div>
      <h1>HomePage</h1>
    </div>
  )
}

export default HomePage
